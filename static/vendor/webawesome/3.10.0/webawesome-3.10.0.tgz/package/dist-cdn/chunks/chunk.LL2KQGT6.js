/*! Copyright 2026 Fonticons, Inc. - https://webawesome.com/license */
import {
  o,
  require_react
} from "./chunk.XJOHOSCS.js";
import {
  WaCheckbox
} from "./chunk.HOR4776U.js";
import {
  __toESM
} from "./chunk.JHZRD2LV.js";

// src/react/checkbox/index.ts
var React = __toESM(require_react(), 1);
var tagName = "wa-checkbox";
var reactWrapper = o({
  tagName,
  elementClass: WaCheckbox,
  react: React,
  events: {
    onWaInvalid: "wa-invalid"
  },
  displayName: "WaCheckbox"
});
var checkbox_default = reactWrapper;

export {
  checkbox_default
};
