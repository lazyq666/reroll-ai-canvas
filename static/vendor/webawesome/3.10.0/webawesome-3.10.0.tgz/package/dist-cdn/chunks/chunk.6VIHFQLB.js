/*! Copyright 2026 Fonticons, Inc. - https://webawesome.com/license */
import {
  i
} from "./chunk.TLFIX76K.js";

// src/components/animation/animation.styles.ts
var animation_styles_default = i`
  :host {
    display: contents;
  }
`;

export {
  animation_styles_default
};
