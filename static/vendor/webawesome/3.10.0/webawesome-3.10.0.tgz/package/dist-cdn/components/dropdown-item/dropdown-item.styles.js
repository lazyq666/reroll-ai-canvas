/*! Copyright 2026 Fonticons, Inc. - https://webawesome.com/license */
import {
  dropdown_item_styles_default
} from "../../chunks/chunk.42BTATE2.js";
import "../../chunks/chunk.TLFIX76K.js";
import "../../chunks/chunk.BKE5EYM3.js";
import "../../chunks/chunk.JHZRD2LV.js";
export {
  dropdown_item_styles_default as default
};
