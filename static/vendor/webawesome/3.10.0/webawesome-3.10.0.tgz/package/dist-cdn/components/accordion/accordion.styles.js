/*! Copyright 2026 Fonticons, Inc. - https://webawesome.com/license */
import {
  accordion_styles_default
} from "../../chunks/chunk.BUCKADPY.js";
import "../../chunks/chunk.TLFIX76K.js";
import "../../chunks/chunk.BKE5EYM3.js";
import "../../chunks/chunk.JHZRD2LV.js";
export {
  accordion_styles_default as default
};
